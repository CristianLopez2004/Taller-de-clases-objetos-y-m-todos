public class Main {
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora();

        double numero1 = 10;
        double numero2 = 5;

        System.out.println("Suma: " + calculadora.sumar(numero1, numero2));
        System.out.println("Resta: " + calculadora.restar(numero1, numero2));
        System.out.println("Multiplicación: " + calculadora.multiplicar(numero1, numero2));
        System.out.println("División: " + calculadora.dividir(numero1, numero2));
    }
}