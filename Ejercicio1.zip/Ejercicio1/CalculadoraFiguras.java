import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CalculadoraFiguras {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.println("Bienvenido a la calculadora de áreas y perímetros de figuras geométricas.");
            System.out.println("Por favor, seleccione la figura que desea calcular:");
            System.out.println("1. Triángulo");
            System.out.println("2. Cuadrado");
            System.out.println("3. Rectángulo");

            int opcion = Integer.parseInt(br.readLine());

            switch (opcion) {
                case 1:
                    calcularTriangulo(br);
                    break;
                case 2:
                    calcularCuadrado(br);
                    break;
                case 3:
                    calcularRectangulo(br);
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción del 1 al 3.");
            }

        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public static void calcularTriangulo(BufferedReader br) throws IOException {
        System.out.println("Ha seleccionado calcular un triángulo.");
        System.out.println("Por favor, ingrese la base del triángulo:");
        double base = Double.parseDouble(br.readLine());
        System.out.println("Por favor, ingrese la altura del triángulo:");
        double altura = Double.parseDouble(br.readLine());

        double area = (base * altura) / 2;
        double perimetro = base * 3; // Perímetro de un triángulo equilátero

        System.out.println("El área del triángulo es: " + area);
        System.out.println("El perímetro del triángulo es: " + perimetro);
    }

    public static void calcularCuadrado(BufferedReader br) throws IOException {
        System.out.println("Ha seleccionado calcular un cuadrado.");
        System.out.println("Por favor, ingrese la longitud del lado del cuadrado:");
        double lado = Double.parseDouble(br.readLine());

        double area = lado * lado;
        double perimetro = 4 * lado;

        System.out.println("El área del cuadrado es: " + area);
        System.out.println("El perímetro del cuadrado es: " + perimetro);
    }

    public static void calcularRectangulo(BufferedReader br) throws IOException {
        System.out.println("Ha seleccionado calcular un rectángulo.");
        System.out.println("Por favor, ingrese la base del rectángulo:");
        double base = Double.parseDouble(br.readLine());
        System.out.println("Por favor, ingrese la altura del rectángulo:");
        double altura = Double.parseDouble(br.readLine());

        double area = base * altura;
        double perimetro = 2 * (base + altura);

        System.out.println("El área del rectángulo es: " + area);
        System.out.println("El perímetro del rectángulo es: " + perimetro);
    }
}
