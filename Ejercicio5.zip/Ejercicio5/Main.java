import java.util.Scanner;
import java.time.LocalDate;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la cédula del empleado:");
        String cedula = scanner.nextLine();

        System.out.println("Ingrese el nombre del empleado:");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el apellido del empleado:");
        String apellido = scanner.nextLine();

        System.out.println("Ingrese el género del empleado (M/F):");
        char genero = scanner.nextLine().charAt(0);

        System.out.println("Ingrese el salario del empleado:");
        double salario = scanner.nextDouble();

        System.out.println("Ingrese la fecha de nacimiento del empleado (YYYY-MM-DD):");
        String fechaNacimientoStr = scanner.next();
        LocalDate fechaNacimiento = LocalDate.parse(fechaNacimientoStr);

        System.out.println("Ingrese la fecha de ingreso del empleado (YYYY-MM-DD):");
        String fechaIngresoStr = scanner.next();
        LocalDate fechaIngreso = LocalDate.parse(fechaIngresoStr);

        Empleado empleado = new Empleado(cedula, nombre, apellido, genero, salario, fechaNacimiento, fechaIngreso);

        System.out.println("¿Desea modificar el salario del empleado? (Sí/No)");
        String respuesta = scanner.next();
        if (respuesta.equalsIgnoreCase("Sí")) {
            System.out.println("Ingrese el nuevo salario del empleado:");
            double nuevoSalario = scanner.nextDouble();
            empleado.modificarSalario(nuevoSalario);
        }

        System.out.println("La edad del empleado es: " + empleado.calcularEdad() + " años");
        System.out.println("Las prestaciones del empleado son: $" + empleado.calcularPrestaciones());

        scanner.close();
    }
}
