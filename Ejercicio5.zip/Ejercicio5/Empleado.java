import java.time.LocalDate;
import java.time.Period;

public class Empleado {

    private String cedula;

    private String nombre;

    private String apellido;

    private char genero;

    private double salario;

    private LocalDate fechaNacimiento;

    private LocalDate fechaIngreso;


    public Empleado(String cedula, String nombre, String apellido, char genero, double salario, LocalDate fechaNacimiento, LocalDate fechaIngreso) {

        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.salario = salario;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaIngreso = fechaIngreso;
    }

    public void modificarSalario(double nuevoSalario) {
        this.salario = nuevoSalario;
        System.out.println("Salario modificado correctamente.");
    }

    public int calcularEdad() {
        LocalDate fechaActual = LocalDate.now();
        Period periodo = Period.between(this.fechaNacimiento, fechaActual);
        return periodo.getYears();
    }

    public double calcularPrestaciones() {
        LocalDate fechaActual = LocalDate.now();
        Period periodo = Period.between(this.fechaIngreso, fechaActual);
        int antiguedad = periodo.getYears();
        return (antiguedad * this.salario) / 12;
    }

}