
import javax.swing.JOptionPane;

public class Vehiculo {
    private String numeroMotor;
    private int numeroVentanas;
    private int cantidadPuertas;
    private String marca;
    private String modelo;
    private double kilometrajeInicial;
    private double kilometrajeFinal;

    public Vehiculo() {
    }

    public void ingresarDatos() {
        this.numeroMotor = JOptionPane.showInputDialog("Ingrese el número de motor:");
        this.numeroVentanas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de ventanas:"));
        this.cantidadPuertas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de puertas:"));
        this.marca = JOptionPane.showInputDialog("Ingrese la marca:");
        this.modelo = JOptionPane.showInputDialog("Ingrese el modelo:");
        this.kilometrajeInicial = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el kilometraje inicial:"));
        this.kilometrajeFinal = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el kilometraje final:"));
    }

    public double calcularKilometrosRecorridos() {
        return this.kilometrajeFinal - this.kilometrajeInicial;
    }

    public void mostrarInformacion() {
        StringBuilder info = new StringBuilder();
        info.append("Información del vehículo:\n");
        info.append("Número de motor: ").append(this.numeroMotor).append("\n");
        info.append("Número de ventanas: ").append(this.numeroVentanas).append("\n");
        info.append("Cantidad de puertas: ").append(this.cantidadPuertas).append("\n");
        info.append("Marca: ").append(this.marca).append("\n");
        info.append("Modelo: ").append(this.modelo).append("\n");
        info.append("Kilometraje inicial: ").append(this.kilometrajeInicial).append(" km\n");
        info.append("Kilometraje final: ").append(this.kilometrajeFinal).append(" km\n");
        info.append("Kilómetros recorridos: ").append(calcularKilometrosRecorridos()).append(" km\n");

        JOptionPane.showMessageDialog(null, info.toString(), "Información del Vehículo", JOptionPane.INFORMATION_MESSAGE);
    }
}