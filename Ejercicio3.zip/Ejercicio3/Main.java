public class Main {
    public static void main(String[] args) {
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.ingresarDatos();
        vehiculo.mostrarInformacion();
    }
}
