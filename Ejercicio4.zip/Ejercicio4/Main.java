import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el precio del producto:");
        double precioProducto = scanner.nextDouble();

        System.out.println("¿El producto tiene IVA? (true/false):");
        boolean tieneIVA = scanner.nextBoolean();

        Producto producto = new Producto(precioProducto, tieneIVA);
        double precioFinal = producto.calcularPrecioFinal();

        System.out.println("El precio final del producto es: $" + precioFinal);

        scanner.close();
    }
}
