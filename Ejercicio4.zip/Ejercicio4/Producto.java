import java.util.Scanner;

public class Producto {
    private double precio;
    private boolean tieneIVA;

    public Producto(double precio, boolean tieneIVA) {
        this.precio = precio;
        this.tieneIVA = tieneIVA;
    }

    public double calcularPrecioFinal() {
        if (!tieneIVA) {
            return precio;
        } else {
            double porcentajeIVA;
            if (precio <= 500) {
                porcentajeIVA = 0.12;
            } else if (precio <= 1500) {
                porcentajeIVA = 0.14;
            } else {
                porcentajeIVA = 0.15;
            }
            return precio * (1 + porcentajeIVA);
        }
    }
}
